
 Here's some markup to style - you have to make it look like the screenshot.

 Don't change the HTML or applied classes. Only write a CSS stylesheet (embedded, or linked -your choice).


A few points to note:

- Only the body font size has been changed (made a bit smaller) and so has the footer. Other font sizes are unchanged.
- The content should be centered

- Make use of the following selectors:   
  i) descendent (ele ele ),   
  ii)child combinator (direct child) (ele > ele ),   
  iii) adjacent sibling {ele + ele }.
  iv) attribute selectors - use these to style the internal and external links

Don't miss the following: 

- the body font color is dark grey
- strapline effect for article titles
- paragraphs following h1 in articles are black
- Note the emboldening in the footer
- external and internal links are styled differently


